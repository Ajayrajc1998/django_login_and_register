from django.db import models


# Create your models here.
# class Department(models.Model):
#     dep_name=models.CharField(max_length=100)
#     def __str__(self):
#         return self.dep_name
class Engineer(models.Model):
    engineer_name=models.CharField(max_length=100)
    #engineer_image=models.ImageField(upload_to='engineers')
    engineer_role=models.TextField()
class Faculty(models.Model):
    f_name=models.CharField(max_length=100)
    f_post=models.TextField()
    f_image=models.ImageField(upload_to='faculty')
    
class Services(models.Model):
    s_name=models.CharField(max_length=100)
    s_info=models.TextField()

from django.contrib import admin
from django.urls import path
from .views import home,register,login_user,logout_user,Engineers,contact,faculty,Our_services

urlpatterns = [
    path('',login_user,name="login_user"),
    path('home/', home,name='home'),
    path('register/',register,name='register'),
    path('logout_user/',logout_user,name="logout_user"),
    path('Engineer/',Engineers,name="Engineer"),
    path('faculty/',faculty,name="faculty"),
    path('contact',contact,name="contact"),
    path('services',Our_services,name='services')
] 
